package Floor;

public enum Fault {
   NONE, FLOOR, DOOR
}
