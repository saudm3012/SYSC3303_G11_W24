package Elevator;

/**
 * Elevator.Direction elevator is currently moving
 * @author Zakariya Khan 101186641
 */
public enum Direction {
    UP, DOWN
}
