package Elevator;

public enum ElevatorStates {
    NOTIFY, PROCESSING, MOVING, STOP
}
