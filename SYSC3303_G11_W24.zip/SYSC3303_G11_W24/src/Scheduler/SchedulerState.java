package Scheduler;

public enum SchedulerState {
    IDLE, PROCESS_REQ, SELECT_REQ
}